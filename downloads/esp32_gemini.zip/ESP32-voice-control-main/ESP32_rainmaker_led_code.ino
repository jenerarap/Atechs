#include "RMaker.h"
#include "WiFi.h"
#include "WiFiProv.h"

// --- SETTINGS ---
#define RELAY_PIN    2   // GPIO 2 is the built-in LED on most boards
const char *service_name = "PROV_12345";
const char *pop = "1234567";

// Define the Device
static Switch my_switch("LED", NULL);

void write_callback(Device *device, Param *param, const param_val_t val, void *priv_data, write_ctx_t *ctx)
{
    const char *device_name = device->getDeviceName();
    const char *param_name = param->getParamName();

    if (strcmp(device_name, "LED") == 0) {
        if (strcmp(param_name, "Power") == 0) {
            Serial.printf("Received value = %s\n", val.val.b ? "true" : "false");
            digitalWrite(RELAY_PIN, val.val.b); 
            param->updateAndReport(val);
        }
    }
}

void sysProvEvent(arduino_event_t *sys_event)
{
    switch (sys_event->event_id) {
        case ARDUINO_EVENT_PROV_START:
            Serial.printf("\nProvisioning Started. Name: %s, PoP: %s\n", service_name, pop);
            printQR(service_name, pop, "ble");
            break;
        case ARDUINO_EVENT_WIFI_STA_CONNECTED:
            Serial.printf("\nConnected to Wi-Fi!\n");
            break;
        case ARDUINO_EVENT_PROV_CRED_RECV:
            Serial.println("\nReceived Wi-Fi credentials");
            break;
    }
}

void setup()
{
    Serial.begin(115200);
    
    // --- SAFE STARTUP FIX ---
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    delay(1000); 
    // ------------------------

    pinMode(RELAY_PIN, OUTPUT);
    digitalWrite(RELAY_PIN, LOW);

    Node my_node;
    my_node = RMaker.initNode("My_Device");

    my_switch.addCb(write_callback);
    my_node.addDevice(my_switch);

    RMaker.start();

    WiFi.onEvent(sysProvEvent);

    // Auto-detect version to prevent compilation errors
    #if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
        WiFiProv.beginProvision(NETWORK_PROV_SCHEME_BLE, NETWORK_PROV_SCHEME_HANDLER_FREE_BTDM, NETWORK_PROV_SECURITY_1, pop, service_name);
    #else
        WiFiProv.beginProvision(WIFI_PROV_SCHEME_BLE, WIFI_PROV_SCHEME_HANDLER_FREE_BTDM, WIFI_PROV_SECURITY_1, pop, service_name);
    #endif
}

void loop()
{
    delay(100); 
}