#include <Servo.h>

Servo servo1;

void setup() {
    Serial.begin(9600);
    servo1.attach(7);
}

void loop() {
    int joystickValue = analogRead(A0);
    Serial.println("Joystick Value:");
    Serial.print(joystickValue);
    delay(100);

    int servoAngle = map(joystickValue, 0, 1023, 0, 180);
    servo1.write(servoAngle);
    delay(100);
}
