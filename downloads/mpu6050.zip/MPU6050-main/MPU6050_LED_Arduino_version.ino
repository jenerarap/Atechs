#include <Wire.h>
#include <MPU6050.h>

MPU6050 mpu;

// Define LED pins
const int redLED = 8;
const int greenLED = 9;
const int blueLED = 10;

void setup() {
  Serial.begin(9600);
  Wire.begin(); // For Arduino, no custom SDA/SCL pins needed
  mpu.initialize();

  pinMode(redLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
  pinMode(blueLED, OUTPUT);

  Serial.println("MPU6050 and LEDs initialized.");
}

void loop() {
  int16_t ax, ay, az, gx, gy, gz;

  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  Serial.print("Accel -> ");
  Serial.print("X: "); Serial.print(ax);
  Serial.print(" | Y: "); Serial.print(ay);
  Serial.print(" | Z: "); Serial.print(az);
  Serial.println();

  // Reset all LEDs
  digitalWrite(redLED, LOW);
  digitalWrite(greenLED, LOW);
  digitalWrite(blueLED, LOW);

  // Respond to tilt based on X and Y
  if (ax < -5000) {
    digitalWrite(redLED, HIGH); // Tilt left
  } else if (ax > 5000) {
    digitalWrite(greenLED, HIGH); // Tilt right
  }

  if (ay > 5000 || ay < -5000) {
    digitalWrite(blueLED, HIGH); // Forward or backward tilt
  }

  delay(300);
}
