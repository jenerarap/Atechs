#include <Wire.h>
#include <MPU6050.h>

MPU6050 mpu;

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);  // ESP32 I2C: SDA=21, SCL=22

  mpu.initialize();  // Init the MPU6050
  Serial.println("MPU6050 connected successfully!");
}

void loop() {
  int16_t ax, ay, az, gx, gy, gz;

  // Get raw data from accelerometer and gyroscope
  mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

  Serial.print("Accel -> ");
  Serial.print("X: "); Serial.print(ax);
  Serial.print(" | Y: "); Serial.print(ay);
  Serial.print(" | Z: "); Serial.print(az);

  Serial.print(" || Gyro -> ");
  Serial.print("X: "); Serial.print(gx);
  Serial.print(" | Y: "); Serial.print(gy);
  Serial.print(" | Z: "); Serial.println(gz);

  delay(500);  // Read every 500ms
}
