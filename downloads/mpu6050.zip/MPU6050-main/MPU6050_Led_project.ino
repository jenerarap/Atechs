#include <Wire.h>
#include <MPU6050.h>

const int redLED = 14;
const int greenLED = 27;
const int blueLED = 26;

MPU6050 mpu;

void setup() {
  // put your setup code here, to run once:
Serial.begin(115200);
Wire.begin(21, 22);
mpu.initialize();
Serial.println("MPU Initialized");
pinMode(redLED, OUTPUT);
pinMode(greenLED, OUTPUT);
pinMode(blueLED, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
int16_t ax, ay, az, gx, gy, gz;

mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

Serial.print("Accel -> ");

Serial.print("X: "); Serial.print(ax);
Serial.print(" | Y: "); Serial.print(ay);
Serial.print(" | Z: "); Serial.print(az);

Serial.print(" || Gyro -> ");

Serial.print("X: "); Serial.print(gx);
Serial.print(" | Y: "); Serial.print(gy);
Serial.print(" | Z: "); Serial.print(gz);

digitalWrite(redLED,LOW);
digitalWrite(greenLED,LOW);
digitalWrite(blueLED,LOW);

if(ax < -5000){
  digitalWrite(redLED, HIGH);
}
else if(ax > 5000){
  digitalWrite(greenLED, HIGH);
}
if(ay > 5000 || ay < -5000){
  digitalWrite(blueLED, HIGH);
}
delay(500);
}
