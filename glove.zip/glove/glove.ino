#define USE_NIMBLE 
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <BleKeyboard.h> 

Adafruit_MPU6050 mpu;
BleKeyboard bleKeyboard("PWM Racing Wheel", "Jener", 100); 

const int turboPin = 19;
const int brakePin = 18;
const float deadzone = 1.5;  
const float maxTilt = 6.0;   
const int pwmCycle = 50;     
unsigned long lastPwmTime = 0;
bool aPressed = false;
bool dPressed = false;
bool turboHeld = false;
bool brakeHeld = false;

void setup() {
  Serial.begin(115200);

  pinMode(turboPin, INPUT_PULLUP);
  pinMode(brakePin, INPUT_PULLUP);

  Wire.begin();

  if (!mpu.begin()) {
    Serial.println("MPU6050 connection failed!");
    while (1) { delay(10); }
  }
  mpu.setAccelerometerRange(MPU6050_RANGE_2_G);
  
  bleKeyboard.begin();
  Serial.println("PWM Keyboard started. Pair it up!");
}

void loop() {
  if (bleKeyboard.isConnected()) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    float roll = a.acceleration.x; 
    unsigned long currentTime = millis();
    unsigned long cycleTime = currentTime - lastPwmTime;

    if (cycleTime >= pwmCycle) {
      lastPwmTime = currentTime;
      cycleTime = 0;
    }

    // 1. RIGHT STEERING 'D'
    if (roll >= maxTilt) {
      if (!dPressed) { bleKeyboard.press('d'); dPressed = true; }
      if (aPressed) { bleKeyboard.release('a'); aPressed = false; }
    }
    else if (roll > deadzone) { 
      float activeRatio = (roll - deadzone) / (maxTilt - deadzone);
      int activeDuration = pwmCycle * activeRatio;
      if (cycleTime < activeDuration) {
        if (!dPressed) { bleKeyboard.press('d'); dPressed = true; }
      } else {
        if (dPressed) { bleKeyboard.release('d'); dPressed = false; }
      }
      if (aPressed) { bleKeyboard.release('a'); aPressed = false; } 
    } 
    
    // 2. LEFT STEERING 'A'
    else if (roll <= -maxTilt) {
      if (!aPressed) { bleKeyboard.press('a'); aPressed = true; }
      if (dPressed) { bleKeyboard.release('d'); dPressed = false; }
    }
    else if (roll < -deadzone) { 
      float activeRatio = (abs(roll) - deadzone) / (maxTilt - deadzone);
      int activeDuration = pwmCycle * activeRatio;
      if (cycleTime < activeDuration) {
        if (!aPressed) { bleKeyboard.press('a'); aPressed = true; }
      } else {
        if (aPressed) { bleKeyboard.release('a'); aPressed = false; }
      }
      if (dPressed) { bleKeyboard.release('d'); dPressed = false; }
    } 
    
    // DEADZONE (RELEASE BOTH)
    else { 
      if (aPressed) { bleKeyboard.release('a'); aPressed = false; }
      if (dPressed) { bleKeyboard.release('d'); dPressed = false; }
    }

    // 3. TURBO BUTTON 'W'
    if (digitalRead(turboPin) == LOW && !turboHeld) {
      bleKeyboard.press('w');
      turboHeld = true;
    } else if (digitalRead(turboPin) == HIGH && turboHeld) {
      bleKeyboard.release('w');
      turboHeld = false;
    }

    // 4. BRAKE BUTTON 'S'
    if (digitalRead(brakePin) == LOW && !brakeHeld) {
      bleKeyboard.press('s');
      brakeHeld = true;
    } else if (digitalRead(brakePin) == HIGH && brakeHeld) {
      bleKeyboard.release('s');
      brakeHeld = false;
    }
  }
}